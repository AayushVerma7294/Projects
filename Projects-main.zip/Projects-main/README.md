# Projects
This is the part where I implement the part that I learn
